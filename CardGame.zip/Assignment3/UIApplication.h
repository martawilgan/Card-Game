//
//  UIApplication.h
//  Assignment3
//
//  Created by marta wilgan on 3/16/13.
//  Copyright (c) 2013 nyu. All rights reserved.
//

#ifndef Assignment3_UIApplication_h
#define Assignment3_UIApplication_h

@interface UIApplication (extended)
-(void) terminateWithSuccess;
@end

#endif
