//
//  Assignment3Tests.h
//  Assignment3Tests
//
//  Created by marta wilgan on 3/13/13.
//  Copyright (c) 2013 nyu. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Assignment3Tests : SenTestCase

@end
